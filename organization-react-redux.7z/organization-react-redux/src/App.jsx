import React from 'react'
import EmployeeCRUD from './components/EmployeeCRUD/EmployeeCRUD'

function App() {
    return (
        <div>
            <EmployeeCRUD />
        </div>
    )
}

export default App;
