import React,{ useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Modal, Button } from 'react-bootstrap';
const MessageBox = (props) => {

	const [show, setShow] = useState(false);
	const handleClose = () => setShow(false)

	return (
		<Modal show={props.show} onHide={handleClose}>
			<Modal.Dialog>
				<Modal.Header closeButton>
					<Modal.Title>{props.modalTitle}</Modal.Title>
				</Modal.Header>

				<Modal.Body>
					<p>{props.modalMessage}</p>
				</Modal.Body>

				<Modal.Footer>
					<Button variant="secondary">Close</Button>
					<Button variant="primary">Ok</Button>
				</Modal.Footer>
			</Modal.Dialog>
		</Modal>
	);
}

export default MessageBox