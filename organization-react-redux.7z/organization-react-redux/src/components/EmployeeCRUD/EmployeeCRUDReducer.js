import {
	CHANGE_EMPFORM_FIELD,
	FETCH_EMPLOYEES_REQUEST,
	FETCH_EMPLOYEES_FAILURE,
	FETCH_EMPLOYEES_SUCCESS,
	FETCH_DEPARTMENTS_REQUEST,
	FETCH_DEPARTMENTS_SUCCESS,
	FETCH_DEPARTMENTS_FAILURE,
	ADD_EMPLOYEE_SUCCESS
} from './EmployeeCRUDActionTypes';

const employeeReducer = (state = initialState, action) => {

	switch (action.type) {
		case CHANGE_EMPFORM_FIELD:
			return {
				...state,
				employee: {
					...state.employee,
					[action.payload.field]: action.payload.value
				}
			}
		case FETCH_EMPLOYEES_REQUEST:
			return {
				...state,
				loading: true
			};
		case FETCH_EMPLOYEES_FAILURE:
			console.log(action.error);
			return {
				...state,
				error: action.error
			};
		case FETCH_EMPLOYEES_SUCCESS:
			let empArr = [];
			action.payload.data.forEach(element => {
				let tempObj = {
					empID: element.empReqVO.empID,
					empFname: element.empReqVO.empFname,
					empLname: element.empReqVO.empLname,
					empDOB: element.empReqVO.empDOB,
					empMobile: element.empReqVO.empMobile,
					empEmail: element.empReqVO.empEmail,
					deptName: element.deptReqVO.deptName,
					deptId: element.deptReqVO.deptId
				}
				empArr.push(tempObj);
			});
			return {
				...state,
				empArr: empArr
			};
		case FETCH_DEPARTMENTS_REQUEST:
			return {
				...state,
				loading: true
			};
		case FETCH_DEPARTMENTS_FAILURE:
			return {
				...state,
				error: action.error
			};
		case FETCH_DEPARTMENTS_SUCCESS:
			let deptArr = [{
				deptId: 0,
				deptName: "Select",
				deptCode: "-"
			}];
			action.payload.data.forEach(deptReqVO => {
				let tempObj = {
					deptId: deptReqVO.deptId,
					deptName: deptReqVO.deptName,
					deptCode: deptReqVO.deptCode
				}
				deptArr.push(tempObj);
			});
			return {
				...state,
				deptArr: deptArr
			};
		case ADD_EMPLOYEE_SUCCESS:
			return {
				...state,
				displayMsgBox:true,
				message:`New Employee Record Created with ID : ${action.payload.response.data.empID}.`,
				title:"Employee Added Successfully."
			};
		default:
			return state;
	}

}


const initialState = {
	empArr: [],
	deptArr: [],
	error: null,
	loading: false,
	title: "",
	message: "",
	displayMsgBox: false,
	department: {
		deptId: "",
		deptName: "",
		deptCode: ""
	},
	employee: {
		empID: "",
		empFname: "",
		empLname: "",
		empDOB: "",
		empMobile: "",
		empEmail: "",
		deptName: "",
		deptId: ""
	}
}

export default employeeReducer;