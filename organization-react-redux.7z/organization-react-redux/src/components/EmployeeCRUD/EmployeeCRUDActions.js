import Axios from 'axios';

import {
	CHANGE_EMPFORM_FIELD,
	FETCH_EMPLOYEES_REQUEST,
	FETCH_EMPLOYEES_FAILURE,
	FETCH_EMPLOYEES_SUCCESS,
	FETCH_DEPARTMENTS_REQUEST,
	FETCH_DEPARTMENTS_SUCCESS,
	FETCH_DEPARTMENTS_FAILURE,
	ADD_EMPLOYEE_SUCCESS
} from './EmployeeCRUDActionTypes';

export const fetchDepartment = () => async(dispatch, getState) =>{
	dispatch({ type: FETCH_DEPARTMENTS_REQUEST });
	try {
		const response = await Axios.get("http://localhost:9090/api/v1/department");
		dispatch({
			type: FETCH_DEPARTMENTS_SUCCESS,
			payload: {
				data: response.data
			}
		})
	} catch (error) {
		dispatch({ type: FETCH_DEPARTMENTS_FAILURE, error })
	}
}

export const fetchEmployees = () => async (dispatch, getState) => {
	dispatch({ type: FETCH_EMPLOYEES_REQUEST });
	try {
		const response = await Axios.get("http://localhost:9090/api/v1/employee");
		dispatch({
			type: FETCH_EMPLOYEES_SUCCESS,
			payload: {
				data: response.data
			}
		})
	} catch (error) {
		dispatch({ type: FETCH_EMPLOYEES_FAILURE, error })
	}
}

export const onFormFieldChange = (event) => (dispatch, getState) => {
	dispatch({
		type:CHANGE_EMPFORM_FIELD,
		payload:{
			field:event.target.name,
			value:event.target.value
		}
	})
}

export const formSubmission = () => (dispatch, getState) =>{
	const employeeObj = {
		empFname:getState().employee.empFname,
		empLname:getState().employee.empLname,
		empDOB:getState().employee.empDOB,
		empMobile:getState().employee.empMobile,
		empEmail:getState().employee.empEmail,
		deptID:getState().employee.deptId
	}
	Axios.post('http://localhost:9090/api/v1/employee',employeeObj)
    .then(function(response){
		dispatch({
			type:ADD_EMPLOYEE_SUCCESS,
			payload:{
				response
			}
		})
	})
    .catch(err => console.log(err))
}