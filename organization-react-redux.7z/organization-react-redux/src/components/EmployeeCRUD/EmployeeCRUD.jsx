import React, { useEffect } from 'react';
import { fetchEmployees, onFormFieldChange, fetchDepartment, formSubmission } from './EmployeeCRUDActions';
import { useSelector, useDispatch } from 'react-redux';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Form, Row, Col, FormControl, FormLabel, FormGroup, Button } from 'react-bootstrap';
import EmployeeVIEW from '../EmployeeVIEW/EmployeeVIEW'
import MessageBox from '../../base-components/MessageBox/MessageBox'

const EmployeeCRUD = () => {

	const state = useSelector(state => state)
	const dispatch = useDispatch()

	useEffect(() => {
		let mounted = true;
		dispatch(fetchEmployees())
		dispatch(fetchDepartment())
		return () => mounted = false;

	}, [])

	const formFieldChange = (event) => {
		dispatch(onFormFieldChange(event))
	}

	const handleFormSubmit = (event) => {
		dispatch(formSubmission());
		event.preventDefault();
	}

	return (
		<Container>
			<MessageBox
				modalTitle = {state.title}
				modalMessage={state.message}
				show={state.displayMsgBox}
			/>
			<h4>
				<u>Add New Employee Entry Into System.</u>
			</h4>
			<Form method="POST">
				<Row>
					<Col>
						<FormGroup>
							<FormLabel htmlFor="empFname"> First Name </FormLabel>
							<FormControl
								name="empFname"
								id="empFname"
								placeholder="First Name"
								value={state.employee.empFname}
								onChange={formFieldChange}
								type="text"
							/>
						</FormGroup>
					</Col>
					<Col>
						<FormGroup>
							<FormLabel htmlFor="empLname"> Last Name </FormLabel>
							<FormControl type="text"
								name="empLname"
								id="empLname"
								placeholder="Last Name"
								value={state.employee.empLname}
								onChange={formFieldChange} />
						</FormGroup>
					</Col>
				</Row>
				<Row>
					<Col>
						<FormGroup>
							<FormLabel> Email </FormLabel>
							<FormControl type="email"
								name="empEmail"
								id="empEmail"
								placeholder="Ex: abc@xyz.com"
								value={state.employee.empEmail}
								onChange={formFieldChange} />
						</FormGroup>
					</Col>
					<Col>
						<FormGroup>
							<FormLabel> Mobile Number </FormLabel>
							<FormControl type="text"
								name="empMobile"
								id="empMobile"
								placeholder="Mobile Number"
								value={state.employee.empMobile}
								onChange={formFieldChange}
								maxLength={10}
								minLength={10} />
						</FormGroup>
					</Col>
				</Row>
				<Row>
					<Col>
						<FormGroup>
							<FormLabel> Date Of Birth </FormLabel>
							<FormControl type="date"
								name="empDOB"
								id="empDOB"
								value={state.employee.empDOB}
								onChange={formFieldChange} />
						</FormGroup>
					</Col>
					<Col>
						<FormGroup>
							<FormLabel> Department </FormLabel>
							<Form.Control as="select" name="deptId" onChange={formFieldChange}>
								{
									state.deptArr.map(ele => {
										return <option value={ele.deptId} key={ele.deptCode}>
											{ele.deptName}
										</option>
									})
								}
							</Form.Control>
						</FormGroup>
					</Col>
				</Row>
				<Row>
					<Col>
						<Button variant="primary" type="submit" onClick={handleFormSubmit}>Add Contact</Button>{' '}
						<Button variant="warning" type="reset">Reset</Button>
					</Col>
				</Row>
			</Form>
			<hr />
			<EmployeeVIEW empArr={state.empArr} />
		</Container>
	)
}

export default EmployeeCRUD
