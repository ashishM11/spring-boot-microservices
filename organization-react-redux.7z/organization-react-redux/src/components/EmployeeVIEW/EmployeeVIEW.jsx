import React, { useEffect } from 'react'
import { FaUserEdit } from "react-icons/fa";
import { IoPersonRemove } from "react-icons/io5";
import './employeeView.css'

const EmployeeVIEW = (props) => {

	useEffect(() => {
	}, [props.empArr])

	return (
		<div>
			<table className="styled-table">
				<thead>
					<tr>
						<th>Employee Id</th>
						<th>First Name</th>
						<th>Last Name</th>
						<th>Date Of Birth</th>
						<th>Mobile Number</th>
						<th>Email Id</th>
						<th>Department</th>
						<th>Modify</th>
						<th>Delete</th>
					</tr>
				</thead>
				<tbody>
					{
						props.empArr.map(e => {
							return <tr key={e.empID}>
								<td>{e.empID}</td>
								<td>{e.empFname}</td>
								<td>{e.empLname}</td>
								<td>{e.empDOB}</td>
								<td>{e.empMobile}</td>
								<td>{e.empEmail}</td>
								<td>{e.deptName}</td>
								<td>
									<button 
									onClick={() => alert('Are you sure for edit')}
								><FaUserEdit /></button></td>
								<td><button ><IoPersonRemove /></button></td>
							</tr>
						})
					}
				</tbody>
			</table>

		</div>
	)
}

export default EmployeeVIEW
